import boto3
import pandas as pd
from io import StringIO, BytesIO
from datetime import datetime

s3_client = boto3.client('s3')

def get_latest_file(bucket, prefix):
    response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
    files = sorted(response['Contents'], key=lambda x: x['LastModified'], reverse=True)
    latest_file = files[0]['Key']
    return latest_file

def lambda_handler(event, context):
    bucket = 'myenergybalnce0978'
    
    # Obtener el archivo CSV más reciente
    csv_prefix = 'TransformerEnergyDispatch/'
    csv_key = get_latest_file(bucket, csv_prefix)
    csv_obj = s3_client.get_object(Bucket=bucket, Key=csv_key)
    csv_data = csv_obj['Body'].read().decode('utf-8')
    
    # Leer el CSV con Pandas
    df_csv = pd.read_csv(StringIO(csv_data), sep='\t')

    # Obtener el archivo Excel más reciente
    excel_prefix = 'FilteredGeneratorDispatch/'
    excel_key = get_latest_file(bucket, excel_prefix)
    excel_obj = s3_client.get_object(Bucket=bucket, Key=excel_key)
    excel_data = excel_obj['Body'].read()
    
    # Leer el Excel con Pandas
    df_excel = pd.read_excel(BytesIO(excel_data))
    
    # Renombrar las columnas del archivo Excel
    df_excel.rename(columns={
        'AÑO': 'anio',
        'MES': 'mes',
        'DÍA': 'dia',
        'HORA': 'hora',
        'CODIGO': 'codigo',
        'CAPACIDAD (Kwh)': 'capacidad'
    }, inplace=True)
    
    # Renombrar las columnas del archivo CSV
    df_csv.rename(columns={
        'anio_despacho': 'anio',
        'mes_despacho': 'mes',
        'dia_despacho': 'dia',
        'hora_despacho': 'hora',
        'codigo': 'codigo',
        'capacidad': 'capacidad_csv'
    }, inplace=True)

    # Convertir a float las capacidades
    df_csv['capacidad_csv'] = df_csv['capacidad_csv'].astype(float)
    df_excel['capacidad'] = df_excel['capacidad'].astype(float)
    
    # Realizar la unión entre ambos DataFrames
    df_merged = pd.merge(df_excel, df_csv, on=['anio', 'mes', 'dia', 'hora', 'codigo'])
    
    # Calcular el balance disponible horario
    df_merged['balance_disponible_horario'] = df_merged['capacidad'] - df_merged['capacidad_csv']
    
    # Agrupar por anio, mes, dia y codigo y sumar el balance
    df_consolidado = df_merged.groupby(['anio', 'mes', 'dia', 'codigo'])['balance_disponible_horario'].sum().reset_index()
    
    # Renombrar la columna del resultado
    df_consolidado.rename(columns={'balance_disponible_horario': 'consolidado_planta'}, inplace=True)

    # Obtener la fecha y hora actual
    now = datetime.now()
    timestamp = now.strftime('%Y%m%d_%H%M%S')
    
    # Guardar el archivo CSV en el prefijo BalanceConsolidado/ con la fecha y hora en el nombre
    output_csv = df_consolidado.to_csv(index=False)
    output_key = f'BalanceConsolidado/BalanceConsolidado_{timestamp}.csv'
    s3_client.put_object(Body=output_csv, Bucket=bucket, Key=output_key)

    return {
        'statusCode': 200,
        'body': f'File saved to {output_key}'
    }
